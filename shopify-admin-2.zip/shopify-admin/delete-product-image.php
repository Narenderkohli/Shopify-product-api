<?php
session_start();

// Ensure the request method is POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die(json_encode(["success" => false, "message" => "Invalid request."]));
}

// Retrieve POST data
$productId = $_POST["productId"] ?? null;
$imageIds = $_POST["imagesToDelete"] ?? [];

if (!$productId || empty($imageIds)) {
    die(json_encode(["success" => false, "message" => "Missing product ID or image IDs."]));
}

// Shopify credentials
$shopifyStore = "shop-test-new93.myshopify.com";
$accessToken = "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";

$errors = [];
foreach ($imageIds as $imageId) {
    // Correct API endpoint with image_id as query parameter
    $url = "https://$shopifyStore/admin/api/2024-01/products/$productId/images/$imageId.json";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "X-Shopify-Access-Token: $accessToken"
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        $errors[] = "Failed to delete image ID: $imageId (HTTP Code: $httpCode)";
    }
}

// Send success or error response
if (empty($errors)) {
    echo json_encode(["success" => true, "message" => "Images deleted successfully."]);
} else {
    echo json_encode(["success" => false, "message" => implode(", ", $errors)]);
}
?>
