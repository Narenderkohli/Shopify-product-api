<?php
session_start();

if (!isset($_SESSION["customer_email"])) {
    header("Location: login.php"); // Redirect if not logged in
    exit;
}

$customerEmail = $_SESSION["customer_email"];

$shopifyStore = "shop-test-new93.myshopify.com";
$accessToken = "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";

// Fetch products from Shopify
$url = "https://$shopifyStore/admin/api/2024-01/products.json";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "X-Shopify-Access-Token: $accessToken"
]);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$customerProducts = [];

if (isset($result["products"])) {
    foreach ($result["products"] as $product) {
        if (strpos($product["tags"], "customer_" . $customerEmail) !== false) {
            $customerProducts[] = $product;
        }
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 1400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: green;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
            vertical-align: top;
        }
        img {
            width: 50px;
            height: 50px;
        }
        .description {
            white-space: pre-wrap; /* Ensures text wraps and preserves new lines */
            word-wrap: break-word;
            text-align: left;
            max-width: 300px; /* Limit width for better readability */
        }
        .edit-button {
            cursor: pointer;
            padding: 5px 10px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }
        .edit-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h4 style='text-align:end;'><a href='all-product.php'>Shopify Products</a></h4>
    <h4 style='text-align:end;'><a href='customer-product.php'>Add Your Products</a></h4>
    <h2>My Products</h2>
    <p style="text-align:end;"><strong>Logged in as:</strong><br> <?= htmlspecialchars($customerEmail); ?> (<a href="logout.php">Logout</a>)</p>
    <h4 style='text-align:end;'><a href='login.php'>Login With Another ID</a></h4>
    
<table>
    <tr> 
        <th>Images</th>
        <th>Title</th>
        <th>Description</th>
        <th>Price</th>
        <th>SKU</th>
        <th>Quantity</th>
        <th>Action</th>
    </tr>
    <?php foreach ($customerProducts as $product) { ?>
    <tr>
        <td>
            <?php if (!empty($product["images"])) { ?>
                <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                    <?php foreach ($product["images"] as $image) { ?>
                        <div style="text-align: center;">
                            <input name='delete_images' type="checkbox" class="image-checkbox" data-product-id="<?= $product['id']; ?>" data-image-id="<?= $image['id']; ?>">
                            <br>
                            <img class="display-image-show" src="<?= htmlspecialchars($image["src"]); ?>" alt="Product Image" 
                                style="width: 50px; height: 50px; border-radius: 5px; object-fit: cover;">
                        </div>
                    <?php } ?>
                </div>
                <br>
                <button class="delete-selected-btn" data-product-id="<?= $product['id']; ?>" 
                    style="display:none; background-color: red; color: white; border: none; padding: 5px; cursor: pointer; border-radius: 3px; margin-top: 5px;">
                    Remove
                </button>
            <?php } else { echo "No Image"; } ?>
        </td>
        <td><?= htmlspecialchars($product["title"]); ?></td>
        <td class="description"><?= !empty($product["body_html"]) ? nl2br($product["body_html"]) : "No Description"; ?></td>
        <td>$<?= htmlspecialchars($product["variants"][0]["price"]); ?></td>
        <td><?= htmlspecialchars($product["variants"][0]["sku"]); ?></td>
        <td><?= htmlspecialchars($product["variants"][0]["inventory_quantity"] ?? "0"); ?></td>
        <td>
            <a class="edit-button" href="edit-product.php?id=<?= $product['id']; ?>">Update</a>
            <a class="edit-button delete-button" data-id="<?= $product['id']; ?>">Delete</a>
        </td>
    </tr>
    <?php } ?>
</table>

</div>
</body>
</html>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
 $(document).on('click','#delete-button',function(){
        console.log("hii");
        var productId = $(this).data("id");
        
        if (confirm("Are you sure you want to delete this product?")) {
            $.ajax({
                url: "delete-product.php",
                type: "POST",
                data: { id: productId },
                success: function(response) {
                    console.log("Product deleted successfully!");
                    location.reload(); 
                },
                error: function() {
                    alert("Failed to delete product.");
                }
            });
        }
    });

   $(document).on('click', '.delete-selected-btn', function() {
    console.log("Delete button clicked");

    var productId = $(this).data("product-id");
    var imagesToDelete = [];

    $("input[name='delete_images']:checked").each(function() {
        imagesToDelete.push($(this).data("image-id"));
    });
  if (confirm("Are you sure you want to delete These Images?")) {
    if (imagesToDelete.length > 0) {
        $.ajax({
            url: 'delete-product-image.php', // Ensure correct path
            type: 'POST',
            dataType: 'json',
            data: {
                productId: productId,
                imagesToDelete: imagesToDelete // Send array directly
            },
            success: function(response) {
                if (response.success) {
                    imagesToDelete.forEach(function(imageId) {
                        $('input[data-image-id="' + imageId + '"]').closest("div").remove();
                    });
                     location.reload(); 
                    $(".delete-selected-btn").hide();
                } else {
                    alert("Failed: " + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error);
                alert("Server error. Check console.");
            }
        });
    } 
   }
   else {
        alert("Please select images to delete.");
    }
});


   function toggleButtonVisibility() {
        $(".delete-selected-btn").each(function () {
            var productId = $(this).data("product-id");
            var checkbox = $(".image-checkbox[data-product-id='" + productId + "']");
            if (checkbox.is(":checked")) {
                $(this).show(); 
            } else {
                $(this).hide(); 
            }
        });
    }
   
    toggleButtonVisibility();

    $(document).on("change", ".image-checkbox", function () {
        toggleButtonVisibility();
    });


   });
</script>

