<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["customer_email"])) {
    $_SESSION["customer_email"] = $_POST["customer_email"]; // Store email in session
    header("Location: customer-product.php"); 
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            color: green;
        }
        input {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: green;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }
        button:hover {
            background-color: darkgreen;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Login</h2>
    <form method="POST">
        <label>Enter Your Email To Add your Own Products:</label>
        <input type="email" name="customer_email" required>
        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>
