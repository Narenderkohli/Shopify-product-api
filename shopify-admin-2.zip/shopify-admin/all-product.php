<?php
// Shopify Admin API credentials
$accessToken = "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";
$shopUrl = "shop-test-new93.myshopify.com";

// Shopify Admin API endpoint to get products
$apiUrl = "https://$shopUrl/admin/api/2024-01/products.json?status=active"; 

// Note: If you want to get all products so remove this attribute end of the $apiUrl url "?status=active"

   
// Initialize cURL session
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "X-Shopify-Access-Token: $accessToken",
    "Content-Type: application/json"
]);

// Execute cURL request
$response = curl_exec($ch);
curl_close($ch);

// Decode JSON response
$products = json_decode($response, true);

// Check if products exist
if (isset($products['products']) && count($products['products']) > 0) {
    // CSS for Grid Layout
    echo "<style>
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            text-align: center;
            border-radius: 8px;
            background: #fff;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .product-card .price {
            color: #27ae60;
            font-size: 18px;
            font-weight: bold;
        }
        .product-card .compare-price {
            color: #e74c3c;
            text-decoration: line-through;
            font-size: 14px;
            margin-left: 5px;
        }
    </style>";

    // Start product grid
    echo "<h2 style='text-align:center;'>Shopify Products</h2>";
    echo "<h4 style='text-align:end;'><a href='login.php'> Add Your Products</a></h4>";
    echo "<div class='product-grid'>";

    foreach ($products['products'] as $product) {
        // Get product details
        $title = $product['title'];
       $product_link = "https://$shopUrl/products/" . $product['handle'];
      $image = isset($product['images'][0]['src']) ? $product['images'][0]['src'] : null; 
        $price = $product['variants'][0]['price'];
        $comparePrice = isset($product['variants'][0]['compare_at_price']) ? $product['variants'][0]['compare_at_price'] : '';

        // Display product card
        echo "<div class='product-card'>";
        if($image !=''){
        echo "<a target='_blank' href='$product_link'><img src='$image' alt='$title'></a>";
      }
      else{
        echo "<a target='_blank' href='$product_link'><img src='https://agrimart.in/uploads/vendor_banner_image/default.jpg' alt='$title'></a>";
      }
        echo "<h3>$title</h3>";
        echo "<p class='price'>$$price";
        if ($comparePrice) {
            echo " <span class='compare-price'>$$comparePrice</span>";
        }
        echo "</p>";
        echo "</div>";
    }

    // Close product grid
    echo "</div>";
} else {
    echo "No products found or an error occurred.";
}
?>
