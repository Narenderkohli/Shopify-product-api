<?php
session_start();

if (!isset($_SESSION["customer_email"])) {
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$shopifyStore = "shop-test-new93.myshopify.com";
$accessToken = "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";

if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(["error" => "Invalid Product ID"]);
    exit;
}

$productId = $_POST['id'];

function deleteProduct($shopifyStore, $accessToken, $productId) {
    $url = "https://$shopifyStore/admin/api/2024-01/products/$productId.json";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "X-Shopify-Access-Token: $accessToken"
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode == 200 || $httpCode == 204;
}

if (deleteProduct($shopifyStore, $accessToken, $productId)) {
    echo json_encode(["success" => "Product deleted successfully"]);
} else {
    echo json_encode(["error" => "Failed to delete product"]);
}
?>
