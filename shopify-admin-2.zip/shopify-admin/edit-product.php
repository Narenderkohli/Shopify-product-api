<?php
session_start();

if (!isset($_SESSION["customer_email"])) {
    header("Location: login.php");
    exit;
}

$customerEmail = $_SESSION["customer_email"];
$shopifyStore = "shop-test-new93.myshopify.com";
$accessToken = "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";

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid Product ID.");
}

$productId = $_GET['id'];

// Fetch product details
function fetchProduct($shopifyStore, $accessToken, $productId) {
    $url = "https://$shopifyStore/admin/api/2024-01/products/$productId.json";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "X-Shopify-Access-Token: $accessToken"
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

$productData = fetchProduct($shopifyStore, $accessToken, $productId);
$product = $productData['product'] ?? null;

if (!$product) {
    die("Product not found.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $sku = $_POST["sku"];
    $quantityChange = (int)$_POST["quantity"]; // User input (can be positive or negative)

    $variant = $product["variants"][0] ?? null;
    if (!$variant) {
        die("Variant not found.");
    }

    $variantId = $variant["id"];
    $inventoryItemId = $variant["inventory_item_id"];

    // Step 1: Update Product Details
    $updateData = [
        "product" => [
            "title" => $title,
            "body_html" => $description,
            "variants" => [
                [
                    "id" => $variantId,
                    "price" => $price,
                    "sku" => $sku
                ]
            ]
        ]
    ];

      // Handle Image Upload
if (!empty($_FILES["images"]["name"][0])) {
    $uploadDir = __DIR__ . "/uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $uploadedImages = [];

    foreach ($_FILES["images"]["tmp_name"] as $key => $tmpName) {
        if ($_FILES["images"]["error"][$key] === UPLOAD_ERR_OK) {
            $imageName = time() . "_" . basename($_FILES["images"]["name"][$key]);
            $imagePath = $uploadDir . $imageName;
            $imageFileType = strtolower(pathinfo($imagePath, PATHINFO_EXTENSION));

            $allowedTypes = ["jpg", "jpeg", "png", "gif", "webp"];
            if (!in_array($imageFileType, $allowedTypes)) {
                die("<p class='error'>Invalid file type. Only JPG, JPEG, PNG, GIF, and WEBP are allowed.</p>");
            }

            if ($_FILES["images"]["size"][$key] > 2 * 1024 * 1024) {
                die("<p class='error'>File is too large. Max 2MB allowed.</p>");
            }

            if (move_uploaded_file($tmpName, $imagePath)) {
                $uploadedImages[] = [
                    "attachment" => base64_encode(file_get_contents($imagePath)),
                    "filename" => $imageName
                ];
            }
        }
    }

    // Fetch current images
    $existingImages = $product["images"] ?? [];
    
    // Append new images to existing ones
    $updateData["product"]["images"] = array_merge($existingImages, $uploadedImages);
}

    // Send Product Update Request
    function updateProduct($shopifyStore, $accessToken, $productId, $updateData) {
        $url = "https://$shopifyStore/admin/api/2024-01/products/$productId.json";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "X-Shopify-Access-Token: $accessToken"
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($updateData));
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    $updateResult = updateProduct($shopifyStore, $accessToken, $productId, $updateData);
// Step 1: Get all locations
    function getInventoryLocations($shopifyStore, $accessToken) {
        $url = "https://$shopifyStore/admin/api/2024-01/locations.json";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "X-Shopify-Access-Token: $accessToken"
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    $locations = getInventoryLocations($shopifyStore, $accessToken);
    if (empty($locations["locations"])) {
        die("No locations found.");
    }

    $locationId = $locations["locations"][0]["id"] ?? null;

    // Step 2: Check if inventory is stocked at the location
    function checkInventoryStock($shopifyStore, $accessToken, $inventoryItemId) {
        $url = "https://$shopifyStore/admin/api/2024-01/inventory_levels.json?inventory_item_ids=$inventoryItemId";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "X-Shopify-Access-Token: $accessToken"
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    $inventoryLevels = checkInventoryStock($shopifyStore, $accessToken, $inventoryItemId);
    $isStocked = false;
    foreach ($inventoryLevels["inventory_levels"] as $level) {
        if ($level["location_id"] == $locationId) {
            $isStocked = true;
            break;
        }
    }

    // Step 3: If not stocked, assign inventory to the location
    if (!$isStocked) {
        function assignInventoryToLocation($shopifyStore, $accessToken, $inventoryItemId, $locationId, $quantity) {
            $url = "https://$shopifyStore/admin/api/2024-01/inventory_levels/set.json";
            $data = [
                "location_id" => $locationId,
                "inventory_item_id" => $inventoryItemId,
                "available" => $quantity
            ];
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json",
                "X-Shopify-Access-Token: $accessToken"
            ]);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            $response = curl_exec($ch);
            curl_close($ch);
            return json_decode($response, true);
        }
        assignInventoryToLocation($shopifyStore, $accessToken, $inventoryItemId, $locationId, 10);
    }

    // Step 4: Update inventory quantity
    function updateInventory($shopifyStore, $accessToken, $inventoryItemId, $quantityChange, $locationId) {
        $url = "https://$shopifyStore/admin/api/2024-01/graphql.json";
        $globalInventoryItemId = "gid://shopify/InventoryItem/$inventoryItemId";
        $globalLocationId = "gid://shopify/Location/$locationId";

        $graphqlQuery = <<<GRAPHQL
        mutation AdjustInventory {
          inventoryAdjustQuantities(input: {
            name: "available",
            reason: "correction",
            changes: [
              {
                inventoryItemId: "$globalInventoryItemId",
                locationId: "$globalLocationId",
                delta: $quantityChange
              }
            ]
          }) {
            userErrors {
              field
              message
            }
          }
        }
        GRAPHQL;

        $payload = json_encode(["query" => trim($graphqlQuery)]);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "X-Shopify-Access-Token: $accessToken"
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    $inventoryUpdateResult = updateInventory($shopifyStore, $accessToken, $inventoryItemId, $quantityChange, $locationId);
    if (empty($inventoryUpdateResult["data"]["inventoryAdjustQuantities"]["userErrors"])) {
        echo "<p class='success'>Inventory updated successfully!</p>";
          header("Location: customer-display-product.php");
        exit();
    } else {
        echo "<p class='error'>Error updating inventory: " . json_encode($inventoryUpdateResult) . "</p>";
    }
 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f8f8;
        }
        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: green;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: green;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }
        button:hover {
            background-color: darkgreen;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
        .success {
            color: green;
            font-weight: bold;
            text-align: center;
        }
        .links {
            text-align: end;
            margin-bottom: 10px;
        }
        .links a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="links">
        <h4><a href='customer-display-product.php'>Back to Products</a></h4>
    </div>
    <h2>Edit Product</h2>

    <form method="POST" enctype="multipart/form-data">
        <label>Title:</label>
        <input type="text" name="title" value="<?= htmlspecialchars($product["title"]); ?>" required>

        <label>Description:</label>
        <textarea name="description" required><?= htmlspecialchars($product["body_html"]); ?></textarea>

        <label>Price:</label>
        <input type="text" name="price" value="<?= htmlspecialchars($product["variants"][0]["price"]); ?>" required>

        <label>SKU:</label>
        <input type="text" name="sku" value="<?= htmlspecialchars($product["variants"][0]["sku"]); ?>" required>

       
        <label>Quantity(To Decrease qauntity use "-" minus sign:</label>
        <input type="number" name="quantity" value="0" required>

        <label>Upload New Image (optional):</label> 
        <input type="file" name="images[]"  multiple accept="image/*" onchange="validateFileCount(this)">
        <button id="product_update" type="submit">Update Product</button>
    </form>
</div>

</body>
</html>

<script>
  function validateFileCount(input) {
    if (input.files.length > 4) {
      alert("You can only upload up to 4 images.");
      input.value = ""; // Clear the input field
    }
  }
</script>