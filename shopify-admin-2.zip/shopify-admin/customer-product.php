<?php 

session_start();

if (!isset($_SESSION["customer_email"])) {
    header("Location: login.php");
    exit;
}

$customerEmail = $_SESSION["customer_email"];

$shopifyStore = "shop-test-new93.myshopify.com";
$accessToken = "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";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $sku = $_POST["sku"];
    $tags = $_POST["tags"];
    $quantity = $_POST["quantity"];

    // Handle Multiple Image Uploads
    $imageData = [];
    $uploadDir = __DIR__ . "/uploads/";

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (!empty($_FILES["images"]["name"][0])) { // Check if at least one image is selected
        foreach ($_FILES["images"]["name"] as $key => $imageName) {
            $imageTmpPath = $_FILES["images"]["tmp_name"][$key];
            $imageFileType = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
            $allowedTypes = ["jpg", "jpeg", "png", "gif"];

            if (!in_array($imageFileType, $allowedTypes)) {
                echo "<p class='error'>Invalid file type: $imageName. Only JPG, JPEG, PNG, and GIF are allowed.</p>";
                continue;
            }

            if ($_FILES["images"]["size"][$key] > 2 * 1024 * 1024) {
                echo "<p class='error'>File too large: $imageName. Max 2MB allowed.</p>";
                continue;
            }

            $newImageName = time() . "_" . basename($imageName);
            $imagePath = $uploadDir . $newImageName;

            if (move_uploaded_file($imageTmpPath, $imagePath)) {
                // Convert Image to Base64
                $imageBase64 = base64_encode(file_get_contents($imagePath));
                $imageData[] = [
                    "attachment" => $imageBase64,
                    "filename" => $newImageName
                ];
            }
        }
    }

    // Prepare Product Data for Shopify API
    $productData = [
        "product" => [
            "title" => $title,
            "body_html" => $description,
            "variants" => [
                [
                    "price" => $price,
                    "sku" => $sku,
                    "inventory_quantity" => (int)$quantity,
                    "inventory_management" => "shopify"
                ]
            ],
            "tags" => $tags . ",customer_" . $customerEmail,
            "images" => $imageData
        ]
    ];

    // Send Data to Shopify
    $url = "https://$shopifyStore/admin/api/2024-01/products.json";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "X-Shopify-Access-Token: $accessToken"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($productData));
    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);

    if (isset($result["product"])) {
        echo "<p class='success'>Product added successfully with images!</p>";
    } else {
        echo "<p class='error'>Error adding product: " . json_encode($result) . "</p>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f8f8;
        }
        .container {
            max-width: 500px;
            margin: auto;
            padding: 20px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: green;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: green;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }
        button:hover {
            background-color: darkgreen;
        }
        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
        .success {
            color: green;
            font-weight: bold;
            text-align: center;
        }
        .links {
            text-align: end;
            margin-bottom: 10px;
        }
        .links a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="links">
        <h4><a href='customer-display-product.php'>See Your Added Products</a></h4>
        <h4><a href='all-product.php'>Shopify Products</a></h4>
    </div>
    <h2>Add Your Product</h2>

    <form method="POST" enctype="multipart/form-data">
        <label>Title:</label>
        <input type="text" name="title" required>

        <label>Description:</label>
        <textarea name="description" required></textarea>

        <label>Price:</label>
        <input type="text" name="price" required>

        <label>SKU:</label>
        <input type="text" name="sku" required>

        <label>Quantity:</label>
        <input type="number" name="quantity" required> <!-- Added Quantity Field -->

        <label>Tags:</label>
        <input type="text" name="tags">

        <label>Upload Image:</label> 
        <input type="file" name="images[]"  multiple  accept="image/*" onchange="validateFileCount(this)">

        <button type="submit">Add Product</button>
    </form>
</div>

</body>
</html>
<script>
  function validateFileCount(input) {
    if (input.files.length > 5) {
      alert("You can only upload up to 5 images.");
      input.value = ""; 
    }
  }
</script>